/*
 * Decompiled with CFR 0_122.
 */
package lumien.chunkanimator.lib;

public class Reference {
    public static final String MOD_ID = "ChunkAnimator";
    public static final String MOD_NAME = "Chunk Animator";
    public static final String MOD_VERSION = "@VERSION@";
}

