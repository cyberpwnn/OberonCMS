/*
 * Decompiled with CFR 0_122.
 * 
 * Could not load the following classes:
 *  cpw.mods.fml.client.config.GuiConfig
 *  cpw.mods.fml.client.config.IConfigElement
 *  net.minecraft.client.gui.GuiScreen
 */
package lumien.chunkanimator.config;

import cpw.mods.fml.client.config.GuiConfig;
import cpw.mods.fml.client.config.IConfigElement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import lumien.chunkanimator.ChunkAnimator;
import lumien.chunkanimator.config.ChunkAnimatorConfig;
import net.minecraft.client.gui.GuiScreen;

public class ChunkAnimatorConfigGui
extends GuiConfig {
    public ChunkAnimatorConfigGui(GuiScreen parent) {
        super(parent, ChunkAnimatorConfigGui.getConfigElements(), "ChunkAnimator", false, false, GuiConfig.getAbridgedConfigPath((String)ChunkAnimator.INSTANCE.config.getString()));
    }

    private static List<IConfigElement> getConfigElements() {
        ArrayList<IConfigElement> list = new ArrayList<IConfigElement>();
        list.addAll(ChunkAnimator.INSTANCE.config.getConfigElements());
        return list;
    }
}

