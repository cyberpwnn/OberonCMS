/*
 * Decompiled with CFR 0_122.
 * 
 * Could not load the following classes:
 *  cpw.mods.fml.relauncher.IFMLLoadingPlugin
 *  cpw.mods.fml.relauncher.IFMLLoadingPlugin$SortingIndex
 */
package lumien.chunkanimator.asm;

import cpw.mods.fml.relauncher.IFMLLoadingPlugin;
import java.util.Map;
import lumien.chunkanimator.asm.ClassTransformer;

@IFMLLoadingPlugin.SortingIndex(value=1001)
public class LoadingPlugin
implements IFMLLoadingPlugin {
    public static boolean IN_MCP = false;

    public String[] getASMTransformerClass() {
        return new String[]{ClassTransformer.class.getName()};
    }

    public String getModContainerClass() {
        return null;
    }

    public String getSetupClass() {
        return null;
    }

    public void injectData(Map<String, Object> data) {
        IN_MCP = (Boolean)data.get("runtimeDeobfuscationEnabled") == false;
    }

    public String getAccessTransformerClass() {
        return null;
    }
}

