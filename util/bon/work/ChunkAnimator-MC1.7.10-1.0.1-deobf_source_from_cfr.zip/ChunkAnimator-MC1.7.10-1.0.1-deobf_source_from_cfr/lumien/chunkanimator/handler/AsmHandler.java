/*
 * Decompiled with CFR 0_122.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.renderer.WorldRenderer
 */
package lumien.chunkanimator.handler;

import java.nio.IntBuffer;
import lumien.chunkanimator.ChunkAnimator;
import lumien.chunkanimator.handler.AnimationHandler;
import net.minecraft.client.renderer.WorldRenderer;

public class AsmHandler {
    public static void callLists(IntBuffer glLists) {
        ChunkAnimator.INSTANCE.animationHandler.callLists(glLists);
    }

    public static void setPosition(WorldRenderer worldRenderer) {
        ChunkAnimator.INSTANCE.animationHandler.setPosition(worldRenderer);
    }
}

