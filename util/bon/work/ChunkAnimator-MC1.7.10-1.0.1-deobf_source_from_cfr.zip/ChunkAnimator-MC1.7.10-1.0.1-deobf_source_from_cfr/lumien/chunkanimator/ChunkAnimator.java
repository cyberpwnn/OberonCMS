/*
 * Decompiled with CFR 0_122.
 * 
 * Could not load the following classes:
 *  cpw.mods.fml.client.event.ConfigChangedEvent
 *  cpw.mods.fml.client.event.ConfigChangedEvent$OnConfigChangedEvent
 *  cpw.mods.fml.common.FMLCommonHandler
 *  cpw.mods.fml.common.Mod
 *  cpw.mods.fml.common.Mod$EventHandler
 *  cpw.mods.fml.common.Mod$Instance
 *  cpw.mods.fml.common.event.FMLPreInitializationEvent
 *  cpw.mods.fml.common.eventhandler.EventBus
 *  cpw.mods.fml.common.eventhandler.SubscribeEvent
 */
package lumien.chunkanimator;

import cpw.mods.fml.client.event.ConfigChangedEvent;
import cpw.mods.fml.common.FMLCommonHandler;
import cpw.mods.fml.common.Mod;
import cpw.mods.fml.common.event.FMLPreInitializationEvent;
import cpw.mods.fml.common.eventhandler.EventBus;
import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import lumien.chunkanimator.config.ChunkAnimatorConfig;
import lumien.chunkanimator.handler.AnimationHandler;

@Mod(modid="ChunkAnimator", name="Chunk Animator", version="@VERSION@", guiFactory="lumien.chunkanimator.config.ChunkAnimatorGuiFactory")
public class ChunkAnimator {
    @Mod.Instance(value="ChunkAnimator")
    public static ChunkAnimator INSTANCE;
    public AnimationHandler animationHandler;
    public ChunkAnimatorConfig config;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        this.animationHandler = new AnimationHandler();
        FMLCommonHandler.instance().bus().register((Object)this);
        this.config = new ChunkAnimatorConfig();
        this.config.preInit(event);
    }

    @SubscribeEvent
    public void onConfigChanged(ConfigChangedEvent.OnConfigChangedEvent event) {
        if (event.modID.equals("ChunkAnimator")) {
            this.config.syncConfig();
        }
    }
}

